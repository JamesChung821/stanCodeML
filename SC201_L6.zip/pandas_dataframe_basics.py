"""
File: pandas_dataframe_basics.py
Name:
-----------------------------------
This file shows the basic pandas syntax, especially
on DataFrame. DataFrame is a 2D data structure, similar to
what a 2D array looks like (or an Excel document).
We will be practicing creating a pandas DataFrame and
call its attributes and methods
"""

import pandas as pd


def main():
    pass


if __name__ == '__main__':
    main()
